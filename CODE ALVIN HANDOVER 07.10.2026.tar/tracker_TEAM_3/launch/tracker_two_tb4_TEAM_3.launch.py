from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('chaser', default_value='tb3_0', description='Chaser robot namespace (e.g. tb3_0 or tb402)'),
        DeclareLaunchArgument('enemy', default_value='tb3_1', description='Enemy robot namespace (e.g. tb3_1 or tb409)'),
        DeclareLaunchArgument('global_frame', default_value='map', description='Global map frame'),
        DeclareLaunchArgument('enemy_offset', default_value='0.5', description='Operating distance offset in meters'),
        
        Node(
            package='tracker_TEAM_3',
            executable='tracker_two_tb4',
            name='tracker_two_tb4',
            output='screen',
            parameters=[{
                'chaser': LaunchConfiguration('chaser'),
                'enemy': LaunchConfiguration('enemy'),
                'global_frame': LaunchConfiguration('global_frame'),
                'enemy_offset': LaunchConfiguration('enemy_offset')
            }]
        )
    ])
