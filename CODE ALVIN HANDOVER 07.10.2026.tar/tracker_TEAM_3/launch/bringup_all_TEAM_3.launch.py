import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    pkg_loc = get_package_share_directory('localization_server_TEAM_3')
    pkg_plan = get_package_share_directory('path_planner_server_TEAM_3')
    pkg_track = get_package_share_directory('tracker_TEAM_3')

    chaser_arg = DeclareLaunchArgument('chaser', default_value='tb3_0', description='Chaser robot namespace')
    enemy_arg = DeclareLaunchArgument('enemy', default_value='tb3_1', description='Enemy robot namespace')
    offset_arg = DeclareLaunchArgument('enemy_offset', default_value='0.5', description='Operating distance offset (m)')

    # 1. Chaser localization
    loc_chaser = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(pkg_loc, 'launch', 'localization_namespaced_TEAM_3.launch.py')),
        launch_arguments={'namespace': LaunchConfiguration('chaser')}.items()
    )

    # 2. Enemy localization
    loc_enemy = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(pkg_loc, 'launch', 'localization_namespaced_TEAM_3.launch.py')),
        launch_arguments={'namespace': LaunchConfiguration('enemy')}.items()
    )

    # 3. Chaser path planner
    plan_chaser = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(pkg_plan, 'launch', 'pathplanner_namespaced_TEAM_3.launch.py')),
        launch_arguments={'namespace': LaunchConfiguration('chaser')}.items()
    )

    # 4. Tracker node
    track_node = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(pkg_track, 'launch', 'tracker_two_tb4_TEAM_3.launch.py')),
        launch_arguments={
            'chaser': LaunchConfiguration('chaser'),
            'enemy': LaunchConfiguration('enemy'),
            'enemy_offset': LaunchConfiguration('enemy_offset')
        }.items()
    )

    return LaunchDescription([
        chaser_arg,
        enemy_arg,
        offset_arg,
        loc_chaser,
        loc_enemy,
        plan_chaser,
        track_node
    ])
