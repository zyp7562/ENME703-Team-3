#!/usr/bin/env python3

import math
import time
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose

from tf2_ros import Buffer, TransformListener, TransformBroadcaster
from tf_transformations import quaternion_from_euler, euler_from_quaternion
from geometry_msgs.msg import TransformStamped, PoseStamped
from sensor_msgs.msg import CompressedImage, Image
from action_msgs.msg import GoalStatus
from scipy.spatial.transform import Rotation as R

try:
    from tracker_interfaces.msg import TrackerReport
except ImportError:
    TrackerReport = None


def extract_robot_id(robot_name: str) -> int:
    """Extract numeric ID that safely fits into uint8 (0-255).
    E.g., 'tb401' -> 1, 'tb402' -> 2, 'tb409' -> 9, 'tb3_0' -> 0, 'tb3_1' -> 1.
    """
    digits = ''.join(filter(str.isdigit, robot_name))
    if not digits:
        return 0
    val = int(digits)
    if 400 <= val < 500:
        val -= 400
    elif 300 <= val < 400:
        val -= 300
    return int(val % 256)


class TrackerTwoTB4(Node):

    def __init__(self):
        super().__init__('tracker_two_tb4')

        # Launch parameters with sensible defaults
        self.declare_parameter('chaser', 'tb401')
        self.declare_parameter('enemy', 'tb409')
        self.declare_parameter('global_frame', 'map')
        self.declare_parameter('enemy_offset', 0.5)         # 0.5m operating distance offset
        self.declare_parameter('enemy_fov', 80.0)           # 80 deg camera HFOV
        self.declare_parameter('enemy_fov_offset', 30.0)    # 30 deg buffer on either side

        chaser_param = self.get_parameter('chaser').value
        enemy_param = self.get_parameter('enemy').value
        self.global_frame = self.get_parameter('global_frame').value

        self.chaser = str(chaser_param).strip('/')
        self.enemy = str(enemy_param).strip('/')
        self.enemy_offset = float(self.get_parameter('enemy_offset').value)
        self.enemy_fov = float(self.get_parameter('enemy_fov').value)
        self.enemy_fov_offset = float(self.get_parameter('enemy_fov_offset').value)

        # Base frames
        self.chaser_base = f'{self.chaser}/base_link'
        self.enemy_base = f'{self.enemy}/base_link'

        # Operating Zone math:
        # Hazard zone is camera FOV (80 deg) + 2x buffer (30 deg each) = 140 deg (+-70 deg from front)
        self.danger_zone_half_angle = (self.enemy_fov / 2.0) + self.enemy_fov_offset  # 70 deg

        # Navigation state tracking
        self.last_enemy_x = None
        self.last_enemy_y = None
        self.last_enemy_yaw = None

        self.last_goal_x = 0.0
        self.last_goal_y = 0.0
        self.last_goal_yaw = 0.0

        self.rel_dist_enemy_in_chaser = 0.0
        self.rel_orient_enemy_in_chaser = 0.0

        self.current_goal_handle = None
        self.sending_goal = False

        # Hit cooldown tracker (5 seconds cooldown between hits)
        self.last_report_time = 0.0
        self.report_cooldown = 5.0

        # Subscriptions for camera - support both TurtleBot 4 (oakd) and TurtleBot 3 simulation
        self.tracker_image = None
        self.create_subscription(
            CompressedImage,
            f'/{self.chaser}/oakd/rgb/preview/image_raw/compressed',
            self.tracker_image_callback,
            10
        )
        self.create_subscription(
            CompressedImage,
            f'/{self.chaser}/camera/image_raw/compressed',
            self.tracker_image_callback,
            10
        )

        # Publishers
        if TrackerReport is not None:
            self.tracker_report_pub = self.create_publisher(
                TrackerReport,
                f'/{self.chaser}/tracker_report',
                10
            )
        else:
            self.tracker_report_pub = None
            self.get_logger().warn("TrackerReport msg not available; tracker_report topic disabled.")

        self.tracker_report_img_pub = self.create_publisher(
            CompressedImage,
            f'/{self.chaser}/tracker_report_img/compressed',
            10
        )

        # TF Buffer, Listener & Broadcaster
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.tf_broadcaster = TransformBroadcaster(self)

        # Nav2 Action Client
        nav_action = f'/{self.chaser}/navigate_to_pose'
        self.nav_client = ActionClient(self, NavigateToPose, nav_action)

        # Main tracking loop at 5 Hz (every 200 ms)
        self.timer = self.create_timer(0.2, self.update_goal)
        self.get_logger().info(
            f"Tracker Two TB4 initialized: Chaser=[{self.chaser}], Enemy=[{self.enemy}], "
            f"GlobalFrame=[{self.global_frame}], Offset=[{self.enemy_offset}m]"
        )

    def tracker_image_callback(self, msg: CompressedImage):
        self.tracker_image = msg

    def homogeneous_T(self, pos, yaw):
        """Construct a 4x4 homogeneous transformation matrix for planar SE(2) in 3D."""
        H = np.eye(4)
        c_yaw = np.cos(yaw)
        s_yaw = np.sin(yaw)
        H[0:2, 0:2] = np.array([[c_yaw, -s_yaw],
                                [s_yaw,  c_yaw]])
        H[0:3, 3] = [pos[0], pos[1], pos[2]]
        return H

    def update_goal(self):
        # 1. Lookup opponent in global map frame
        try:
            enemy_tf = self.tf_buffer.lookup_transform(
                self.global_frame, self.enemy_base, rclpy.time.Time()
            )
        except Exception as e:
            self.get_logger().warn(f"Waiting for enemy TF ({self.global_frame} -> {self.enemy_base}): {e}", throttle_duration_sec=2.0)
            return

        # 2. Lookup relative transform: enemy in chaser frame
        try:
            rel_tf_enemy_in_chaser = self.tf_buffer.lookup_transform(
                self.chaser_base, self.enemy_base, rclpy.time.Time()
            )
        except Exception as e:
            self.get_logger().warn(f"Waiting for relative TF ({self.chaser_base} -> {self.enemy_base}): {e}", throttle_duration_sec=2.0)
            return

        # 3. Lookup relative transform: chaser in enemy frame
        try:
            rel_tf_chaser_in_enemy = self.tf_buffer.lookup_transform(
                self.enemy_base, self.chaser_base, rclpy.time.Time()
            )
        except Exception as e:
            self.get_logger().warn(f"Waiting for relative TF ({self.enemy_base} -> {self.chaser_base}): {e}", throttle_duration_sec=2.0)
            return

        enemy_x = enemy_tf.transform.translation.x
        enemy_y = enemy_tf.transform.translation.y
        _, _, enemy_yaw = euler_from_quaternion([
            enemy_tf.transform.rotation.x, enemy_tf.transform.rotation.y,
            enemy_tf.transform.rotation.z, enemy_tf.transform.rotation.w
        ])

        # Relative measurements of enemy in chaser frame
        rel_x_enemy_in_chaser = rel_tf_enemy_in_chaser.transform.translation.x
        rel_y_enemy_in_chaser = rel_tf_enemy_in_chaser.transform.translation.y
        rel_q = rel_tf_enemy_in_chaser.transform.rotation
        _, _, rel_yaw_enemy_in_chaser = euler_from_quaternion([
            rel_q.x, rel_q.y, rel_q.z, rel_q.w
        ])

        self.rel_dist_enemy_in_chaser = math.hypot(rel_x_enemy_in_chaser, rel_y_enemy_in_chaser)
        self.rel_orient_enemy_in_chaser = math.degrees(rel_yaw_enemy_in_chaser)

        # Chaser's bearing angle from the enemy's perspective
        rel_x_chaser_in_enemy = rel_tf_chaser_in_enemy.transform.translation.x
        rel_y_chaser_in_enemy = rel_tf_chaser_in_enemy.transform.translation.y
        chaser_bearing_in_enemy = math.degrees(math.atan2(rel_y_chaser_in_enemy, rel_x_chaser_in_enemy))

        # Enemy's bearing angle from the chaser's perspective (is enemy in front of chaser camera?)
        enemy_bearing_in_chaser = math.degrees(math.atan2(rel_y_enemy_in_chaser, rel_x_enemy_in_chaser))

        in_enemy_danger_zone = abs(chaser_bearing_in_enemy) < self.danger_zone_half_angle
        if in_enemy_danger_zone:
            self.get_logger().warn("Warning: Inside Enemy Danger Zone!", throttle_duration_sec=1.5)

        # --- Capture & Reporting Check ---
        # Operating zone: 220 deg arc (outside the 140 deg danger cone: abs(bearing) >= 70 deg)
        in_operating_zone = not in_enemy_danger_zone
        within_capture_distance = (0.30 <= self.rel_dist_enemy_in_chaser <= 0.75)
        chaser_facing_enemy = (abs(enemy_bearing_in_chaser) <= 45.0)

        now_sec = self.get_clock().now().nanoseconds / 1e9
        if (in_operating_zone and within_capture_distance and chaser_facing_enemy and
                (now_sec - self.last_report_time >= self.report_cooldown)):
            self.trigger_capture_report("Operating Zone Criteria Satisfied")

        # --- Desired Goal Pose Calculation ---
        # Desired pose is directly behind the opponent (-offset on local X axis), facing along the opponent's heading
        H_enemy_in_map = self.homogeneous_T(np.array([enemy_x, enemy_y, 0.0]), enemy_yaw)
        H_d_in_enemy = self.homogeneous_T(np.array([-self.enemy_offset, 0.0, 0.0]), 0.0)
        H_d_in_map = H_enemy_in_map @ H_d_in_enemy

        goal_x = float(H_d_in_map[0, 3])
        goal_y = float(H_d_in_map[1, 3])
        R_d_in_map = R.from_matrix(H_d_in_map[0:3, 0:3])
        _, _, goal_yaw = R_d_in_map.as_euler('xyz', degrees=False)

        # Broadcast tracking goal TF for RViz inspection (fulfils rubric visualization requirement)
        self.broadcast_goal_tf(goal_x, goal_y, goal_yaw)

        # --- Goal Dispatching & Dynamic Updating ---
        # Update goal if:
        #  1) Never dispatched before
        #  2) Enemy moved > 0.20m since last dispatched goal
        #  3) Enemy heading rotated > 20 deg (0.35 rad)
        should_send = False
        if self.last_enemy_x is None:
            should_send = True
        else:
            enemy_dist_moved = math.hypot(enemy_x - self.last_enemy_x, enemy_y - self.last_enemy_y)
            yaw_diff = abs(math.atan2(math.sin(enemy_yaw - self.last_enemy_yaw), math.cos(enemy_yaw - self.last_enemy_yaw)))
            if enemy_dist_moved > 0.20 or yaw_diff > 0.35:
                should_send = True

        if should_send and not self.sending_goal:
            self.send_goal(goal_x, goal_y, goal_yaw)
            self.last_enemy_x = enemy_x
            self.last_enemy_y = enemy_y
            self.last_enemy_yaw = enemy_yaw
            self.last_goal_x = goal_x
            self.last_goal_y = goal_y
            self.last_goal_yaw = goal_yaw

    def broadcast_goal_tf(self, x, y, yaw):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = self.global_frame
        t.child_frame_id = f'{self.chaser}_tracking_goal'
        t.transform.translation.x = float(x)
        t.transform.translation.y = float(y)
        t.transform.translation.z = 0.0
        q = quaternion_from_euler(0.0, 0.0, yaw)
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]
        self.tf_broadcaster.sendTransform(t)

    def send_goal(self, x, y, yaw):
        if not self.nav_client.wait_for_server(timeout_sec=0.5):
            self.get_logger().warn(f"Nav2 action server /{self.chaser}/navigate_to_pose not available", throttle_duration_sec=2.0)
            return

        self.sending_goal = True

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = self.global_frame
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = float(x)
        goal_msg.pose.pose.position.y = float(y)
        goal_msg.pose.pose.position.z = 0.0

        q = quaternion_from_euler(0.0, 0.0, yaw)
        goal_msg.pose.pose.orientation.x = q[0]
        goal_msg.pose.pose.orientation.y = q[1]
        goal_msg.pose.pose.orientation.z = q[2]
        goal_msg.pose.pose.orientation.w = q[3]

        self.get_logger().info(f"Pursuit goal dispatched: x={x:.2f}, y={y:.2f}, yaw={math.degrees(yaw):.1f} deg")

        future = self.nav_client.send_goal_async(goal_msg)
        future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        self.sending_goal = False
        goal_handle = future.result()

        if not goal_handle.accepted:
            self.get_logger().warn("Pursuit goal rejected by Nav2")
            return

        self.current_goal_handle = goal_handle
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self.goal_result_callback)

    def goal_result_callback(self, future):
        result = future.result()
        status = result.status

        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info("Pursuit goal reached successfully!")
            self.trigger_capture_report("Goal Succeeded")
        elif status == GoalStatus.STATUS_ABORTED:
            self.get_logger().warn("Goal aborted by Nav2 - tracking loop will dispatch next goal.")
        elif status == GoalStatus.STATUS_CANCELED:
            self.get_logger().info("Goal preempted/canceled for updated target.")

    def trigger_capture_report(self, reason: str):
        now_sec = self.get_clock().now().nanoseconds / 1e9
        if now_sec - self.last_report_time < self.report_cooldown:
            return

        if self.tracker_image is None:
            self.get_logger().warn(f"Capture trigger [{reason}], but no camera image received yet!")
            return

        self.last_report_time = now_sec

        my_id = extract_robot_id(self.chaser)
        opp_id = extract_robot_id(self.enemy)

        if self.tracker_report_pub is not None:
            report = TrackerReport()
            report.my_id = int(my_id)
            report.opp_id = int(opp_id)
            report.image = self.tracker_image
            report.rel_dist = float(self.rel_dist_enemy_in_chaser)
            report.rel_orient = float(self.rel_orient_enemy_in_chaser)
            self.tracker_report_pub.publish(report)

        self.tracker_report_img_pub.publish(self.tracker_image)

        self.get_logger().info(
            f"=== TARGET CAPTURED ({reason}) ===\n"
            f"  My ID: {my_id} | Opponent ID: {opp_id}\n"
            f"  Relative Distance: {self.rel_dist_enemy_in_chaser:.2f} m\n"
            f"  Relative Orientation: {self.rel_orient_enemy_in_chaser:.1f} deg\n"
            f"  Report & Image successfully published!"
        )


def main():
    rclpy.init()
    node = TrackerTwoTB4()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()